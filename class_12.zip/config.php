<?php
    $host = "localhost";
    $database = "lop_12a3";
    $user = "root";
    $password = "";
?>