<?php
    session_start();
    include "config.php";
    include "app/connection.php";
    include "app/controller.php";
    include "app/routing.php";
?>