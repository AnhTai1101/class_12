<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>Lê Công Tài</title>
    <link rel="stylesheet" href="assets/frontend/style.css">
</head>

<body>
    <canvas></canvas>
    <a class="name"ref="https://mobilebbz.000webhostapp.com/class"><span class="noname">Hello Class 12A3</span></a>
    <script type="text/javascript" src="assets/frontend/name.js"></script>
</body>

</html>